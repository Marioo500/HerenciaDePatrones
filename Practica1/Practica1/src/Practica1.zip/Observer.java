public interface Observer {
    public void update(float temp,  float h, float p);
}